import React from 'react';

const Requests = ({ match }) => (
  <div>
    
  </div>
);

export default Requests;