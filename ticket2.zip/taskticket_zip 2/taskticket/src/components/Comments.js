import React from 'react';

class Comments extends React{
    render(){
        return (
            <div className="comment">
                I'm the comments!!!
            </div>
        )
    }
};

export default Comments;